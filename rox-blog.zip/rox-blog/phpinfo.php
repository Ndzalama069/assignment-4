<?php
   phpinfo();
   ?>
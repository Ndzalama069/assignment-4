<?php
include 'db.php'; // Include the database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About - Rox Blog</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Georgia', serif;
      margin: 0;
      padding: 0;
    }
    .navbar {
      background-color: #343a40 !important;
    }
    .navbar-brand {
      font-size: 1.5rem;
      font-weight: bold;
    }
    .footer {
      background-color: #343a40;
      color: white;
      padding: 20px 0;
      text-align: center;
    }
    .about-section {
      padding: 50px 0;
      background-color: #f8f9fa;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
      <a class="navbar-brand" href="index.php">Rox Blog</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="about.php">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- About Section -->
  <div class="about-section">
    <div class="container">
      <h1 class="text-center mb-4">About Rox Blog</h1>
      <p class="lead text-center">Welcome to Rox Blog, your go-to destination for exploring the beauty of nature.</p>
      <div class="row mt-5">
        <div class="col-md-6">
          <h2>Our Mission</h2>
          <p>At Rox Blog, we aim to inspire and educate our readers about the wonders of nature. Through captivating stories, stunning photography, and insightful articles, we hope to foster a deeper appreciation for the natural world.</p>
        </div>
        <div class="col-md-6">
          <h2>Our Story</h2>
          <p>Founded in 2023, Rox Blog began as a passion project by a group of nature enthusiasts. Over time, it has grown into a thriving community of like-minded individuals who share a love for the outdoors.</p>
        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <div class="footer">
    <div class="container">
      <p class="mb-0">&copy; 2023 Rox Blog. All rights reserved.</p>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
// Include the database connection
include 'db.php';

// Get the post ID from the URL
$post_id = $_GET['id'];

// Fetch the blog post from the database
$stmt = $conn->prepare("SELECT * FROM blog_posts WHERE id = :id");
$stmt->bindParam(':id', $post_id);
$stmt->execute();
$post = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch comments for this post
$stmt = $conn->prepare("SELECT * FROM comments WHERE post_id = :post_id ORDER BY created_at DESC");
$stmt->bindParam(':post_id', $post_id);
$stmt->execute();
$comments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $post['title']; ?></title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h1><?php echo $post['title']; ?></h1>
  <?php if (!empty($post['image_path'])): ?>
    <img src="<?php echo $post['image_path']; ?>" class="img-fluid mb-4" alt="Post Image">
  <?php endif; ?>
  <p><?php echo $post['content']; ?></p>
  <p class="text-muted">By <?php echo $post['author']; ?> on <?php echo $post['created_at']; ?></p>
</div>

        <!-- Display comments -->
        <h3>Comments</h3>
        <?php foreach ($comments as $comment): ?>
            <div class="card mb-3">
                <div class="card-body">
                    <p class="card-text"><?php echo $comment['comment']; ?></p>
                    <p class="text-muted">By <?php echo $comment['commenter_name']; ?> on <?php echo $comment['created_at']; ?></p>
                </div>
            </div>
        <?php endforeach; ?>

        <!-- Form to add a new comment -->
        <h3>Add a Comment</h3>
        <form action="add_comment.php" method="POST">
            <input type="hidden" name="post_id" value="<?php echo $post_id; ?>">
            <div class="mb-3">
                <label for="commenter_name" class="form-label">Your Name</label>
                <input type="text" class="form-control" id="commenter_name" name="commenter_name" required>
            </div>
            <div class="mb-3">
                <label for="comment" class="form-label">Comment</label>
                <textarea class="form-control" id="comment" name="comment" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Add Comment</button>
        </form>
    </div>
</body>
</html>
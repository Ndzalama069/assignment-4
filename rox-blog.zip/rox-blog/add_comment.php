<?php
// Include the database connection
include 'db.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $post_id = $_POST['post_id'];
    $commenter_name = $_POST['commenter_name'];
    $comment = $_POST['comment'];

    // Prepare SQL query to insert the comment into the database
    $stmt = $conn->prepare("INSERT INTO comments (post_id, commenter_name, comment) VALUES (:post_id, :commenter_name, :comment)");
    // Bind parameters to the query
    $stmt->bindParam(':post_id', $post_id);
    $stmt->bindParam(':commenter_name', $commenter_name);
    $stmt->bindParam(':comment', $comment);

    // Execute the query
    if ($stmt->execute()) {
        // Redirect back to the post page after successful submission
        header("Location: post.php?id=$post_id");
    } else {
        // Display an error message if something goes wrong
        echo "Error adding comment.";
    }
}
?>
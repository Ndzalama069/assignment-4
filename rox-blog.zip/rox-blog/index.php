<?php
// Include the database connection
include 'db.php';

// Fetch all blog posts from the database
$stmt = $conn->query("SELECT * FROM blog_posts ORDER BY created_at DESC");
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rox Blog - Home</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Georgia', serif;
    }
    .navbar {
      background-color: #343a40 !important;
    }
    .navbar-brand {
      font-size: 1.5rem;
      font-weight: bold;
    }
    .jumbotron {
      background: url('https://via.placeholder.com/1500x500') no-repeat center center;
      background-size: cover;
      color: blue;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
      padding: 100px 0;
      margin-bottom: 0;
    }
    .card {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
      transform: scale(1.02);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
    .footer {
      background-color: #343a40;
      color: white;
      padding: 20px 0;
      text-align: center;
    }
    /* Add this for equal image sizes */
    .card-img-top {
      width: 100%; /* Ensure the image takes up the full width of the card */
      height: 200px; /* Set a fixed height for all images */
      object-fit: cover; /* Ensure the image covers the container without distortion */
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
      <a class="navbar-brand" href="index.php">Rox Blog</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="create_post.php">Create Post</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Jumbotron -->
  <div class="jumbotron text-center">
    <div class="container">
      <h1 class="display-4">Welcome to Rox Blog</h1>
      <p class="lead">Explore the beauty of nature with us.</p>
    </div>
  </div>

  <!-- Blog Posts -->
  <div class="container py-5">
    <div class="row">
      <?php foreach ($posts as $post): ?>
        <div class="col-md-4 mb-4">
          <div class="card">
            <?php if (!empty($post['image_path'])): ?>
              <img src="<?php echo $post['image_path']; ?>" class="card-img-top" alt="Post Image">
            <?php endif; ?>
            <div class="card-body">
              <h2 class="card-title"><?php echo $post['title']; ?></h2>
              <p class="card-text"><?php echo substr($post['content'], 0, 100) . '...'; ?></p>
              <p class="text-muted">By <?php echo $post['author']; ?> on <?php echo $post['created_at']; ?></p>
              <a href="post.php?id=<?php echo $post['id']; ?>" class="btn btn-primary">Read More</a>
              <a href="delete_post.php?id=<?php echo $post['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this post?')">Delete</a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Footer -->
  <div class="footer">
    <div class="container">
      <p class="mb-0">&copy; 2023 Rox Blog. All rights reserved.</p>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
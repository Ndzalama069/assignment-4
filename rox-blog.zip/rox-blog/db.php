<?php
$host = 'localhost'; // Database host (usually 'localhost')
$dbname = 'rox_blog'; // Database name
$username = 'root'; // Database username (default for XAMPP/MAMP is 'root')
$password = ''; // Database password (default for XAMPP/MAMP is empty)

try {
    // Create a connection to the database
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // If connection fails, display an error message
    echo "Connection failed: " . $e->getMessage();
}
?>
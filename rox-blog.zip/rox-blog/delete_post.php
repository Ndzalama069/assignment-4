<?php
// Include the database connection
include 'db.php';

// Check if the post ID is provided in the URL
if (isset($_GET['id'])) {
    $post_id = $_GET['id'];

    // Fetch the post to get the image path
    $stmt = $conn->prepare("SELECT image_path FROM blog_posts WHERE id = :id");
    $stmt->bindParam(':id', $post_id);
    $stmt->execute();
    $post = $stmt->fetch(PDO::FETCH_ASSOC);

    // Delete the post from the database
    $stmt = $conn->prepare("DELETE FROM blog_posts WHERE id = :id");
    $stmt->bindParam(':id', $post_id);

    if ($stmt->execute()) {
        // Delete the associated image file
        if (!empty($post['image_path']) && file_exists($post['image_path'])) {
            unlink($post['image_path']);
        }
        // Redirect to the homepage after successful deletion
        header("Location: index.php");
    } else {
        echo "Error deleting post.";
    }
} else {
    echo "No post ID provided.";
}
?>